<?php
    $serveur = "localhost";
    $dbname = "server_cilent";
    $user = "root";
    $pass = " ";
    
    $Compteurmachine = $_POST["Compteurmachine"];
    $appreciation1 = $_POST["appreciation1"];
    $appreciation2 = $_POST["appreciation2"];
    $appreciation3 = $_POST["appreciation3"];
    $appreciation4 = $_POST["appreciation4"];
    $appreciation5 = $_POST["appreciation5"];
    
    
    try{
        //On se connecte à la BDD
        $dbco = new PDO("mysql:host=$serveur;dbname=$dbname",$user,$pass);
        $dbco->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
        //On insère les données reçues
        $sth = $dbco->prepare("
            INSERT INTO checklistenccss (Compteurmachine,appreciation1, appreciation2, appreciation3, appreciation4, appreciation5)
            VALUES(:Compteurmachine,  :appreciation1, :appreciation2,:appreciation3,:appreciation4,:appreciation5)");
        $sth->bindParam(':Compteurmachine',$Compteurmachine);
        $sth->bindParam(':appreciation1',$appreciation1);
        $sth->bindParam(':appreciation2',$appreciation2);
        $sth->bindParam(':appreciation3',$appreciation3);
        $sth->bindParam(':appreciation4',$appreciation4);
        $sth->bindParam(':appreciation5',$appreciation5);
        $sth->execute();
        
        //On renvoie l'utilisateur vers la page de remerciement
        header("Location:thanks_encaisseuse.php");
    }
    catch(PDOException $e){
        echo 'Impossible de traiter les données. Erreur : '.$e->getMessage();
    }
?>