<!DOCTYPE html>
<html>
<head>
    <title>cour PHP/ mySQL</title>
    <meta charset="utf-8">
    <link rel="stylesheet"  href="style.css">
    <link rel="stylesheet" type="checklist_dateuse/css" href="">
</head>
 <form style="position: relative;">
  <img src="logo_bracongo.jpg" border="" />
  <div style="position: absolute; left: 600px; top: 100px;"> 
<body>
<h1>Succes</h1>
<p> les données ont bien été enregistrées </p>
<form action="checklist_dateuse.php" method="post">

<p>
    <input type="submit" value="Afficher les données" />
</p>
</form>
</form>
<div class="c100">
    <a href='affichage_dateuse.php'><span>Afficher/span></a>
    </div> 

     </div>
</body>
</html>  