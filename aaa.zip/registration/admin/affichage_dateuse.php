
<?php
  $host = 'localhost';
  $dbname = 'server_cilent';
  $username = 'root';
  $password = '';
    
  $dsn = "mysql:host=$host;dbname=$dbname"; 
  // récupérer tous les utilisateurs
  $sql = "SELECT * FROM checklistdecais";
   
  try{
   $pdo = new PDO($dsn, $username, $password);
   $stmt = $pdo->query($sql);
   
   if($stmt === false){
    die("Erreur");
   }
   
  }catch (PDOException $e){
    echo $e->getMessage();
  }
?>
<!DOCTYPE html>
<html>
<body>
 <h1>CHECK LIST SUIVI FONCTIONNEMENT SUIVI DATEUSE L5</h1>
 <table>
   <thead>
     <tr>
       <th>ID</th>
       <th>verification conformité date</th>
       <th>verification conformité date</th>
       <th>verification conformité date</th>
       <th>verification conformité date</th>
       <th>date</th>
       <th>heure</th>
     </tr>
   </thead>
   <tbody>
     <?php while($row = $stmt->fetch(PDO::FETCH_ASSOC)) : ?>
     <tr>
       <td><?php echo htmlspecialchars($row['id']); ?></td>
       <td><?php echo htmlspecialchars($row['appreciation1']); ?></td>
       <td><?php echo htmlspecialchars($row['appreciation2']); ?></td>
       <td><?php echo htmlspecialchars($row['appreciation3']); ?></td>
       <td><?php echo htmlspecialchars($row['appreciation4']); ?></td>
       <td><?php echo htmlspecialchars($row['date']); ?></td>
       <td><?php echo htmlspecialchars($row['heure']); ?></td>
     </tr>
     <?php endwhile; ?>
   </tbody>