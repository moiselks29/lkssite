<?php
    $serveur = "localhost";
    $dbname = "server_cilent";
    $user = "root";
    $pass = "";
    
    try{
        //On se connecte à la BDD
        $dbco = new PDO("mysql:host=$serveur;dbname=$dbname",$user,$pass);
        $dbco->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
        //On crée une table form
        $form = "CREATE TABLE checklistdateuse(
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            heure TIME, appreciation1 TEXT, appreciation2 TEXT, appreciation3 TEXT, appreciation4 TEXT, date DATE)";
        $dbco->exec($form);

         }
    catch(PDOException $e){
        echo 'Erreur : '.$e->getMessage();
    }
?>
 