<!DOCTYPE html>
<html>
<head>
    <title>cours PHP/ mySQL</title>
    <meta charset="utf-8">
    <link rel="stylesheet"  href="stylee.css">


</head>

 <?php
 session_start();
                
 ?>

<h1 style="color:green;font-size:40px;"><center>CHECK LIST SUIVI FONCTIONNEMENT SUIVI DATEUSE L5</center> </h1>

        
        <form action="recup_dateuse.php" method="post">
              
              <form style="position: relative;">
                <img src="logo_bracongo.jpg" border="" />
                <div style="position: absolute; left: 500px; top: 100px;"> 
            <div class="c100">
              <h5 style="color:black;font-size:20px;">Verification conformité date</h5>

              <div>


                <input type="radio" id="oui" name="appreciation1" value="oui"required>
                <label for="oui">oui</label>
                <input type="radio" id="non" name="appreciation1" value="non"required>
                <label for="non">non</label>
                </div>

                <div>

                <input type="radio" id="oui" name="appreciation2" value="oui"required>
                <label for="oui">oui</label>
                <input type="radio" id="non" name="appreciation2" value="non"required>
                <label for="non">non</label>

                </div>
               
            </div>
             <div class="c100">
                <h5 style="color:black;font-size:20px;">verification conformité date</h5>
                 <div>


                <input type="radio" id="oui" name="appreciation3" value="oui"required>
                <label for="oui">oui</label>
                <input type="radio" id="non" name="appreciation3" value="non"required>
                <label for="non">non</label>
                </div>

                <div>

                <input type="radio" id="oui" name="appreciation4" value="oui"required>
                <label for="oui">oui</label>
                <input type="radio" id="non" name="appreciation4" value="non"required>
                <label for="non">non</label>

                </div>
               
            </div>
            <div class="c100">
              <h5 style="color:black;font-size:20px;">Verification conformité date</h5>

              <div>


                <input type="radio" id="oui" name="appreciation1" value="oui"required>
                <label for="oui">oui</label>
                <input type="radio" id="non" name="appreciation1" value="non"required>
                <label for="non">non</label>
                </div>

                <div>

                <input type="radio" id="oui" name="appreciation1" value="oui"required>
                <label for="oui">oui</label>
                <input type="radio" id="non" name="appreciation1" value="non"required>
                <label for="non">non</label>

                </div>
               
            </div>
             
             <div class="c100" id="submit">
                <input type="submit" value="Enregistrer">
            </div>
            </div>
            </form>


          
        </form>
</html>

   