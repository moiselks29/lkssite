<!DOCTYPE html>
<html>
<head>
    <title>cours PHP/ mySQL</title>
    <meta charset="utf-8">
    <link rel="stylesheet"  href="stylee.css">


</head>

 <?php
 session_start();
                
 ?>

<h1 style="color:green;font-size:40px;"><center>CHECK LIST SOUTIREUSE EN PRODUCTION L5</center> </h1>

        
        <form action="recup_soutireuse.php" method="post">
              
              <form style="position: relative;">
                <img src="logo_bracongo.jpg" border="" />
                <div style="position: absolute; left: 500px; top: 95px;"> 
      
           
             <div class="c100">
              <h5 style="color:black;font-size:20px;">Machine propre</h5>


                <input type="radio" id="OK" name="appreciation1" value="OK" required>
                <label for="OK">OK</label>
                <input type="radio" id="non" name="appreciation1" value="non" required>
                <label for="non">non</label>
               
            </div>
            <div class="c100">
              <h5 style="color:black;font-size:20px;">Etancheité robinet de remplissage </h5>


                <input type="radio" id="OK" name="appreciation2" value="OK" required>
                <label for="OK">OK</label>
                <input type="radio" id="non" name="appreciation2" value="non" required>
                <label for="non">non</label>
               
            </div>
            <div class="c100">
              <h5 style="color:black;font-size:20px;">Lubrification capsuleuse</h5>


                <input type="radio" id="OK" name="appreciation3" value="OK" required>
                <label for="OK">OK</label>
                <input type="radio" id="non" name="appreciation3" value="non" required>
                <label for="non">non</label>
               
            </div>
            <div class="c100">
              <h5 style="color:black;font-size:20px;">Tapis transporteur à bouchon</h5>


                <input type="radio" id="OK" name="appreciation4" value="OK" required>
                <label for="OK">OK</label>
                <input type="radio" id="non" name="appreciation4" value="non" required>
                <label for="non">non</label>
               
            </div>
            <div class="c100">
              <h5 style="color:black;font-size:20px;">Fonctionnement pomes à vide</h5>


                <input type="radio" id="OK" name="appreciation5" value="OK" required>
                <label for="OK">OK</label>
                <input type="radio" id="non" name="appreciation5" value="non" required>
                <label for="non">non</label>
               
            </div>
            <div class="c100">
              <h5 style="color:black;font-size:20px;">Etat joint cannules + fulpers</h5>


                <input type="radio" id="OK" name="appreciation6" value="OK" required>
                <label for="OK">OK</label>
                <input type="radio" id="non" name="appreciation6" value="non" required>
                <label for="non">non</label>
               
            </div>
            <div class="c100">
              <h5 style="color:black;font-size:20px;">Douche sortie</h5>


                <input type="radio" id="OK" name="appreciation7" value="OK" required>
                <label for="OK">OK</label>
                <input type="radio" id="non" name="appreciation7" value="non" required>
                <label for="non">non</label>
               
            </div>
             <div class="c100">
              <h5 style="color:black;font-size:20px;">Explosion des bouteilles</h5>


                <input type="radio" id="OK" name="appreciation8" value="OK" required>
                <label for="OK">OK</label>
                <input type="radio" id="non" name="appreciation8" value="non" required>
                <label for="non">non</label>
               
            </div>
             <div class="c100" id="submit">
                <input type="submit" value="Enregistrer">
            </div>
            </div>
            </form>


          
        </form>
</html>

   