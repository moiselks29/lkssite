
<?php
  $host = 'localhost';
  $dbname = 'server_cilent';
  $username = 'root';
  $password = '';
    
  $dsn = "mysql:host=$host;dbname=$dbname"; 
  // récupérer tous les utilisateurs
  $sql = "SELECT * FROM checklistsout";
   
  try{
   $pdo = new PDO($dsn, $username, $password);
   $stmt = $pdo->query($sql);
   
   if($stmt === false){
    die("Erreur");
   }
   
  }catch (PDOException $e){
    echo $e->getMessage();
  }
?>
<!DOCTYPE html>
<html>
<body>
 <h1>DECAISSEUSE L5</h1>
 <table>
   <thead>
     <tr>
       <th>ID</th>
       <th>Machine propre</th>
       <th>Fonctionnement tete d'enprehension </th>
       <th>tancheité robinet de remplissage</th>
       <th>Lubrification capsuleuse</th>
       <th>Fonctionnement pompes a vide</th>
       <th>Etat joint cannules + fulpers</th>
       <th>Douche de sortie</th>
       <th>Explosion bouteilles</th>
       <th>Tapis transporteur à bouchon</th>
       <th>date</th>
       <th>heure</th>
     </tr>
   </thead>
   <tbody>
     <?php while($row = $stmt->fetch(PDO::FETCH_ASSOC)) : ?>
     <tr>
       <td><?php echo htmlspecialchars($row['id']); ?></td>
       <td><?php echo htmlspecialchars($row['machinePropre']); ?></td>
       <td><?php echo htmlspecialchars($row['ERR']); ?></td>
       <td><?php echo htmlspecialchars($row['LC']); ?></td>
       <td><?php echo htmlspecialchars($row['TTB']); ?></td>
       <td><?php echo htmlspecialchars($row['FPV']); ?></td>
       <td><?php echo htmlspecialchars($row['EJCT']); ?></td>
       <td><?php echo htmlspecialchars($row['DS']); ?></td>
       <td><?php echo htmlspecialchars($row['explBlles']); ?></td>
       <td><?php echo htmlspecialchars($row['date']); ?></td>
       <td><?php echo htmlspecialchars($row['heure']); ?></td>
     </tr>
     <?php endwhile; ?>
   </tbody>