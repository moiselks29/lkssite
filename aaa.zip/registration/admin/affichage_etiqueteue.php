
<?php
  $host = 'localhost';
  $dbname = 'server_cilent';
  $username = 'root';
  $password = '';
    
  $dsn = "mysql:host=$host;dbname=$dbname"; 
  // récupérer tous les utilisateurs
  $sql = "SELECT * FROM checklistdettiq";
   
  try{
   $pdo = new PDO($dsn, $username, $password);
   $stmt = $pdo->query($sql);
   
   if($stmt === false){
    die("Erreur");
   }
   
  }catch (PDOException $e){
    echo $e->getMessage();
  }
?>
<!DOCTYPE html>
<html>
<body>
 <h1>Etiqueteuse L5</h1>
 <table>
   <thead>
     <tr>
       <th>ID</th>
       <th>Compteur machine</th>
       <th>Compteur check mat sortie etiqueteuse (bouteilles)</th>
       <th>Total entrée </th>
       <th>production</th>
       <th>ejetion</th>
       <th>Pression de travail d'air comprimé = 6 bars</th>
       <th>Bon fonctionnement pompe a colle</th>
       <th>1erposte</th>
       <th>2eposte</th>
       <th>date</th>
       <th>heure</th>
     </tr>
   </thead>
   <tbody>
     <?php while($row = $stmt->fetch(PDO::FETCH_ASSOC)) : ?>
     <tr>
       <td><?php echo htmlspecialchars($row['id']); ?></td>
       <td><?php echo htmlspecialchars($row['compteurmachine']); ?></td>
       <td><?php echo htmlspecialchars($row['appreciation1']); ?></td>
       <td><?php echo htmlspecialchars($row['1erposte']); ?></td>
       <td><?php echo htmlspecialchars($row['2eposte']); ?></td>
       <td><?php echo htmlspecialchars($row['Totalentrée']); ?></td>
       <td><?php echo htmlspecialchars($row['production']); ?></td>
        <td><?php echo htmlspecialchars($row['Ejections']); ?></td>
       <td><?php echo htmlspecialchars($row['date']); ?></td>
       <td><?php echo htmlspecialchars($row['heure']); ?></td>
     </tr>
     <?php endwhile; ?>
   </tbody>