
<?php
  $host = 'localhost';
  $dbname = 'server_cilent';
  $username = 'root';
  $password = '';
    
  $dsn = "mysql:host=$host;dbname=$dbname"; 
  // récupérer tous les utilisateurs
  $sql = "SELECT * FROM checklistdecais";
   
  try{
   $pdo = new PDO($dsn, $username, $password);
   $stmt = $pdo->query($sql);
   
   if($stmt === false){
    die("Erreur");
   }
   
  }catch (PDOException $e){
    echo $e->getMessage();
  }
?>
<!DOCTYPE html>
<html>
<body>
 <h1>DECAISSEUSE L5</h1>
 <table>
   <thead>
     <tr>
       <th>ID</th>
       <th>Compteur machine</th>
       <th>Machine propre</th>
       <th>Fonctionnement tete d'enprehension </th>
       <th>Bon fonctionnement convoyeur d'encaissage</th>
       <th>Lubrification teble de sortie(savon)</th>
       <th>Pression de travail d'air comprimé = 6 bars</th>
       <th>date</th>
       <th>heure</th>
     </tr>
   </thead>
   <tbody>
     <?php while($row = $stmt->fetch(PDO::FETCH_ASSOC)) : ?>
     <tr>
       <td><?php echo htmlspecialchars($row['id']); ?></td>
       <td><?php echo htmlspecialchars($row['compteurmachine']); ?></td>
       <td><?php echo htmlspecialchars($row['appreciation1']); ?></td>
       <td><?php echo htmlspecialchars($row['appreciation2']); ?></td>
       <td><?php echo htmlspecialchars($row['appreciation3']); ?></td>
       <td><?php echo htmlspecialchars($row['appreciation4']); ?></td>
       <td><?php echo htmlspecialchars($row['appreciation5']); ?></td>
       <td><?php echo htmlspecialchars($row['date']); ?></td>
       <td><?php echo htmlspecialchars($row['heure']); ?></td>
     </tr>
     <?php endwhile; ?>
   </tbody>