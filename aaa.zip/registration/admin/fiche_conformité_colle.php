<!DOCTYPE html>
<html>
<head>
    <title>cours PHP/ mySQL</title>
    <meta charset="utf-8">
    <link rel="stylesheet"  href="stylee.css">


</head>

 <?php
 session_start();
                
 ?>

<h1 style="color:green;font-size:40px;"><center>FICHE DE CONTROLE DE LA CONFORMITE DE LA CONSOMATION COLLE L5</center> </h1>

        
        <form action="formulaire2.php" method="post">
              
              <form style="position: relative;">
                <img src="logo_bracongo.jpg" border="" />
                <div style="position: absolute; left: 500px; top: 150px;"> 

                 

                 <div class="c100">

                <label for="date"> DATE : </label>
                <input type="text" id="date" name="date" required>
            </div>
               <div class="c100">

                <label for="Quantité colle(XG)"> Quantité colle(XG): </label>
                <input type="text" id="Quantité colle(XG)" name="Quantité colle(XG)" required>
            </div>
             <div class="c100">

                <label for="Index compteur bouteille etiqueteuse(début)"> Index compteur bouteille etiqueteuse(début) : </label>
                <input type="text" id="Index compteur bouteille etiqueteuse(début)" name="Index compteur bouteille etiqueteuse(début)" required>
            </div>
             <div class="c100">

                <label for="Index fin compteur bouteille"> Index fin compteur bouteille : </label>
                <input type="text" id="Index fin compteur bouteille" name="Index fin compteur bouteille" required>
            </div>
             <div class="c100">

                <label for=" Produit soutiré"> Produit soutiré : </label>
                <input type="text" id=" Produit soutiré" name=" Produit soutiré" required>
            </div>

            <div class="c100">

                <label for=" Nom opérateur "> Nom opérateur : </label>
                <input type="text" id=" Nom opérateur " name=" Nom opérateur " required>
            </div>
      
            
             <div class="c100" id="submit">
                <input type="submit" value="Enregistrer">
            </div>
            </div>
            </form>


          
        </form>
</html>

   