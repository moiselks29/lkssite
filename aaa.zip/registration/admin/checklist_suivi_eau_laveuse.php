<!DOCTYPE html>
<html>
<head>
    <title>cours PHP/ mySQL</title>
    <meta charset="utf-8">
    <link rel="stylesheet"  href="stylee.css">


</head>

 <?php
 session_start();
                
 ?>

<h1 style="color:green;font-size:40px;"><center>CHECK LIST SUIVI HORAIRE CONSOMMATION EAU L5</center> </h1>

        
        <form action="recup_suivieau_lav.php" method="post">
              
              <form style="position: relative;">
                <img src="logo_bracongo.jpg" border="" />
                <div style="position: absolute; left: 500px; top: 100px;"> 
               <div class="c100">

                <label for="Compteurmachine"> Compteurmachine : </label>
                <input type="text" id="Compteurmachine" name="Compteurmachine">
            </div>
            <div class="c100">
              <h5 style="color:black;font-size:20px;">Machine propre</h5>


                <input type="radio" id="oui" name="appreciation1" value="oui"required>
                <label for="oui">oui</label>
                <input type="radio" id="non" name="appreciation1" value="non"required>
                <label for="non">non</label>
               
            </div>
             <div class="c100">
                <h5 style="color:black;font-size:20px;">Heure(H) - Heure(H-1)</h5>
                <input type="radio" id="oui" name="appreciation2" value="oui"required>
                <label for="oui">oui</label>
                <input type="radio" id="non" name="appreciation2" value="non"required>
                <label for="non">non</label>
                 <div class="c100">

                <label for="Target"> Target : </label>
                <input type="text" id="Target" name="Target"required>
            </div>
               
            </div>
             <div class="c100">
              <h5 style="color:black;font-size:20px;">Consommation réelle par bille(ml/b) </h5>

                
                <input type="radio" id="oui" name="appreciation3" value="oui"required>
                <label for="oui">oui</label>
                <input type="radio" id="non" name="appreciation3" value="non"required>
                <label for="non">non</label>
               
            </div>
             <div class="c100">
                <h5 style="color:black;font-size:20px;">Fonctionnement rouleau a la sortie</h5>

                <input type="radio" id="oui" name="appreciation4" value="oui"required>
                <label for="oui">oui</label>
                <input type="radio" id="non" name="appreciation4" value="non"required>
                <label for="non">non</label>
               
            </div>
             <div class="c100">
              <h5 style="color:black;font-size:20px;">Cadence machine(b/h)</h5>

                
                <input type="radio" id="oui" name="appreciation5" value="oui"required>
                <label for="oui">oui</label>
                <input type="radio" id="non" name="appreciation5" value="non"required>
                <label for="non">non</label>
               
            </div>
            <div class="c100">
              <h5 style="color:black;font-size:20px;">Compteur machine en casiers</h5>

                
                <input type="radio" id="oui" name="appreciation6" value="oui"required>
                <label for="oui">oui</label>
                <input type="radio" id="non" name="appreciation6" value="non"required>
                <label for="non">non</label>
               
            </div>
             <div class="c100">

                <label for="Observation"> Observation/Suggestions/Problèmes constants : </label>
                <input type="text" id="Observation" name="Observation">
            </div>


             <div class="c100" id="submit">
                <input type="submit" value="Enregistrer">
            </div>
            </div>
            </form>


          
        </form>
</html>

   