<?php
    $serveur = "localhost";
    $dbname = "server_cilent";
    $user = "root";
    $pass = " ";
    
    $appreciation1 = $_POST["appreciation1"];
    $appreciation2 = $_POST["appreciation2"];
   
  
    
    
    try{
        //On se connecte à la BDD
        $dbco = new PDO("mysql:host=$serveur;dbname=$dbname",$user,$pass);
        $dbco->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
        //On insère les données reçues
        $sth = $dbco->prepare("
            INSERT INTO checklistdateuse ( appreciation1, appreciation2)
            VALUES(:appreciation1, :appreciation2)");
       
        $sth->bindParam(':appreciation1',$appreciation1);
        $sth->bindParam(':appreciation2',$appreciation2);
       
        $sth->execute();
        
        //On renvoie l'utilisateur vers la page de remerciement
        header("Location:thanks_dateuse.php");
    }
    catch(PDOException $e){
        echo 'Impossible de traiter les données. Erreur : '.$e->getMessage();
    }
?>