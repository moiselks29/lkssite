<?php
  // Initialiser la session
  session_start();
  // Vérifiez si l'utilisateur est connecté, sinon redirigez-le vers la page de connexion
  if(!isset($_SESSION["username"])){
    header("Location: login.php");
    exit(); 
  }
?>
<!DOCTYPE html>
<html>
  <head>
     <style>
      * {
        margin: 0;
        padding: 0;

        list-style-type: none;
        box-sizing: border-box;
      }
      body {
        background: url("") center;
        background-size: cover;
        min-height: 1000px;
        font-family: "Helvetica Neue", sans-serif;
      }
      nav {
        text-align: center;
      }
      .menu {
        display: inline-block;
      }
      .menu > li {
        float: left;
        color: #FFFFFF;
        width: 150px;
        height: 40px;
        line-height: 40px;
        background: rgb(46,139,87);
        cursor: pointer;
        font-size: 17px;
      }
      .sub-menu {
        transform: scale(0);
        transform-origin: top center;
        transition: all 300ms ease-in-out;
      }
      .sub-menu li {
        font-size: 14px;
        background: rgb(255,255,255);
        padding: 8px 0;
        color: green;
        border-bottom: 1px solid rgba(255,255,255 0.2);
        transform: scale(0);
        transform-origin: top center;
        transition: all 300ms ease-in-out;
      }
      .sub-menu li:last-child {
        border-bottom: 0;
      }
      .sub-menu li:hover {
        background: skyblue;
      }
      .menu > li:hover .sub-menu li {
        transform: scale(1);
      }
      .menu > li:hover .sub-menu {
        transform: scale(1);
      }
    </style>
  <link rel="stylesheet" href="" />
  </head>
  <form style="position: relative;">
                <img src="logo_bracongo.jpg" border="" />
                <div style="position: absolute; left: 110px; top: 0px;"> 

  <body>
     <body style='background:#fff;'>
        <body>
    <nav>
      <ul class="menu">
        <li>
          ENCAISSEUSE
          <ul class="sub-menu">
            <li>Checklist encaisseuse</li>
            <li>Maintenance journalière</li>
          </ul>
        </li>
        <li>
          DECAISSEUSE
          <ul class="sub-menu">
            <li>Checklist decaisseuse</li>
            <li>maintenance journalière</li>
          </ul>
        </li>
        <li>
          PALETTISEUR
          <ul class="sub-menu">
            <li><a href="formulaire.php">Checklist palettiseur</a></li>
            <li>Maintenance journalière</li>
          </ul>
        </li>
        <li>
          DEPALETTISEUR
          <ul class="sub-menu">
            <li>Checklist depaletiseur</li>
            <li>maintenance journalière</li>
          </ul>
        </li>
        <li>
          LAVEUSE BOUTEILLES
          <ul class="sub-menu">
            <li>Checklist laveuse bouteilles/li>
            <li>Maintenance journalière</li>
          </ul>
        </li>

        <li>
            SOUTIREUSE
          <ul class="sub-menu">
            <li>Checklist soutireuser</li>
            <li>maintenance journalière</li>
          </ul>
        </li>
        <li>
            SOUTIREUSE
          <ul class="sub-menu">
            <li>Checklist soutireuser</li>
            <li>maintenance journalière</li>
          </ul>
        </li>
        <li>
            ETTIQUETEUSE
          <ul class="sub-menu">
            <li>Checklist soutireuser</li>
            <li>maintenance journalière</li>
          </ul>
        </li>

      </ul>

    </nav>
    <div class="sucess">
    <h1>Bienvenue <?php echo $_SESSION['username']; ?>!</h1>
    <p>C'est votre espace utilisateur.</p>
    <a href="logout.php">Déconnexion</a>
    </div>
  </body>
</html>