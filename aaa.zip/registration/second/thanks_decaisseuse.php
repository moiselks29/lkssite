<!DOCTYPE html>
<html>
<head>
    <title>cour PHP/ mySQL</title>
    <meta charset="utf-8">
    <link rel="stylesheet"  href="stylee.css">
    <link rel="stylesheet" type="Decaisseuse_fiche/css" href="">
</head>
 <form style="position: relative;">
  <img src="logo_bracongo.jpg" border="" />
  <div style="position: absolute; left: 600px; top: 100px;"> 
<body>
<h1>Succes</h1>
<p> les données ont bien été enregistrées </p>
<form action="Decaisseuse_fiche.php" method="post">

<p>
    <input type="submit" value="Afficher les données" />
</p>
</form>
</form>
<div class="c100">
    <a href='affichage_decaisseuse.php'><span>Affichage</span></a>
    </div> 

  <?php
session_start();
                if(isset($_GET['deconnexion']))
                { 
                   if($_GET['deconnexion']==true)
                   {  
                      session_unset();
                      header("location:login.php");
                   }
               }
               ?>
               

                </div>
</body>
</html>  