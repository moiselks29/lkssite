<?php
    $serveur = "localhost";
    $dbname = "server_cilent";
    $user = "root";
    $pass = " ";
    
    $Compteurmachine = $_POST["Compteurmachine"];
    $appreciation1 = $_POST["appreciation1"];
    $erposte = $_POST["erposte"];
    $eposte = $_POST["eposte"];
    $Totalentrée = $_POST["Totalentrée"];
    $Production = $_POST["Production"];
    $Ejections = $_POST["Ejections"];
    
    
    
    try{
        //On se connecte à la BDD
        $dbco = new PDO("mysql:host=$serveur;dbname=$dbname",$user,$pass);
        $dbco->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
        //On insère les données reçues
        $sth = $dbco->prepare("
            INSERT INTO checklistettiq (Compteurmachine, appreciation1, erposte, eposte, Totalentrée, Production, Ejections)
            VALUES(:Compteurmachine, :appreciation1, :erposte, :eposte,: Totalentrée, :Production,  :Ejections )");
        $sth->bindParam(':Compteurmachine',$Compteurmachine);
        $sth->bindParam(':appreciation1',$appreciation1);
        $sth->bindParam(':erposte',$erposte);
        $sth->bindParam('eposte',$eposte);
        $sth->bindParam(':Totalentrée',$Totalentrée);
        $sth->bindParam(':Production',$Production);
        $sth->bindParam(':Ejections',$Ejections);
        $sth->execute();
        
        //On renvoie l'utilisateur vers la page de remerciement
        header("Location:form-merci.php");
    }
    catch(PDOException $e){
        echo 'Impossible de traiter les données. Erreur : '.$e->getMessage();
    }
?>